import 'package:ecommerce_admin_panel/features/shop/product/product_images_controller.dart';
import 'package:ecommerce_admin_panel/features/shop/screens/dashboard/table/data_table.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../common/widgets/containers/rounded_container.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../../utils/device/device_utility.dart';
import '../../../controllers/dashboard/dashboard_controller.dart';
import '../widgets/order_status_pie_chart.dart';
import '../widgets/t_dashboard_card.dart';
import '../widgets/weekly_sales.dart';

class DashboardDesktopScreen extends StatelessWidget {
  const DashboardDesktopScreen({super.key});

  @override
  Widget build(BuildContext context) {
final controller=Get.put(ProductImagesController());
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(TSizes.defaultSpace),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Dashboard', style: Theme.of(context).textTheme.headlineLarge),
              ElevatedButton(onPressed: ()=>controller.selectThumbnailImage(), child: const Text('selectsinglr image')),
              const SizedBox(height: TSizes.spaceBtwSections),
              ElevatedButton(onPressed: ()=>controller.selectMultipleProductImages(), child: const Text('select multiple single image')),
              const SizedBox(height: TSizes.spaceBtwSections),
              Row(
                children: [
                  Expanded(
                    child: TDashboardCard(title: 'Sales total', subTitle: '\$365.6', stats: 25),
                  ),
                  SizedBox(width: TSizes.spaceBtwItems),
                  Expanded(
                    child: TDashboardCard(title: 'Average Order', subTitle: '\$25', stats: 15),
                  ),
                  SizedBox(width: TSizes.spaceBtwItems),
                  Expanded(
                    child: TDashboardCard(title: 'Total Order', subTitle: '\$36', stats: 44),
                  ),
                  SizedBox(width: TSizes.spaceBtwItems),
                  Expanded(
                    child: TDashboardCard(title: 'Visitors', subTitle: '\$25.66', stats: 2),
                  ),
                ],
              ),
              SizedBox(height: TSizes.spaceBtwSections),
              // Graphs
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 2,
                    child: Column(
                      children: [
                        // Bar Graph
                        TWeeklySalesGraph(),
                        SizedBox(height: TSizes.spaceBtwSections),
                        // Orders
                        TRoundedContainer(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Recent Orders',style: Theme.of(context).textTheme.headlineSmall,),
                              const SizedBox(height: TSizes.spaceBtwSections,),
                              const DashboardOrderTable()
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: TSizes.spaceBtwSections),
                  // Pie chart
                  Expanded(child: TOrderStatusPieChart(),),

                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

}