import 'package:ecommerce_admin_panel/common/widgets/images/t_rounded_image.dart';
import 'package:ecommerce_admin_panel/utils/constants/colors.dart';
import 'package:ecommerce_admin_panel/utils/constants/enums.dart';
import 'package:ecommerce_admin_panel/utils/constants/image_strings.dart';
import 'package:flutter/material.dart';

import '../../../../../../common/widgets/containers/rounded_container.dart';
import '../../../../../../utils/constants/sizes.dart';
import '../../../../models/order_model.dart';

class OrderCustomer extends StatelessWidget {
  const OrderCustomer({super.key, required this.order});
  final OrderModel order;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TRoundedContainer(
          padding: EdgeInsets.all(TSizes.defaultSpace),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Customers', style: Theme.of(context).textTheme.headlineMedium),
              SizedBox(height: TSizes.spaceBtwSections),
              Row(
                children: [
                  TRoundedImage(imageType: ImageType.asset,
                  image: TImages.user,
                    backgroundColor: TColors.primaryBackground,
                    padding: 0,
                  ),
                  SizedBox(width: TSizes.spaceBtwItems,),
                  Expanded(child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Tomas Ecommerce system',style: Theme.of(context).textTheme.titleLarge,overflow: TextOverflow.ellipsis,maxLines: 1,),
                      Text('TomasEcommwcrce@gmail.com',overflow: TextOverflow.ellipsis,maxLines: 1,),

                    ],
                  ))
                ],
              ),
            ],
          ),
        ),

        SizedBox(height: TSizes.spaceBtwSections,),
        SizedBox(
          width: double.infinity,
          child: TRoundedContainer(
            padding: EdgeInsets.all(TSizes.defaultSpace),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Contact Person',style: Theme.of(context).textTheme.headlineMedium,),
                SizedBox(height: TSizes.spaceBtwSections,),
                Text('Tomas Ecommerce',style: Theme.of(context).textTheme.titleSmall,),
                SizedBox(height: TSizes.spaceBtwItems/2,),
                Text('Support@gmail.com',style: Theme.of(context).textTheme.titleSmall,),
                SizedBox(height: TSizes.spaceBtwItems/2,),
                Text('(+251)*********',style: Theme.of(context).textTheme.titleSmall,)
              ],

            ),
          ),
        ),
        SizedBox(height: TSizes.spaceBtwSections,),
        SizedBox(
          width: double.infinity,
          child: TRoundedContainer(
            padding: EdgeInsets.all(TSizes.defaultSpace),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Shopping Address',style: Theme.of(context).textTheme.headlineMedium,),
                SizedBox(height: TSizes.spaceBtwSections,),
                Text('Addis Ababa',style: Theme.of(context).textTheme.headlineSmall,),
                SizedBox(height: TSizes.spaceBtwItems/2,),
                Text('Addis Ababa,Ethiopia',style: Theme.of(context).textTheme.titleSmall,),
              ],
            ),
          ),
        ) ,
        SizedBox(height: TSizes.spaceBtwSections,),
        SizedBox(
          width: double.infinity,
          child: TRoundedContainer(
            padding: EdgeInsets.all(TSizes.defaultSpace),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Billing Address',style: Theme.of(context).textTheme.headlineMedium,),
                SizedBox(height: TSizes.spaceBtwSections,),
                Text('Addis Ababa',style: Theme.of(context).textTheme.headlineSmall,),
                SizedBox(height: TSizes.spaceBtwItems/2,),
                Text('Addis Ababa,Ethiopia',style: Theme.of(context).textTheme.titleSmall,),
              ],
            ),
          ),
        ),
        SizedBox(height: TSizes.spaceBtwSections,)
      ],
    );
  }
}
