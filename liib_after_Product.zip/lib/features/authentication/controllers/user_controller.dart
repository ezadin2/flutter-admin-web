import 'package:get/get.dart';

import '../../../common/styles/user_model.dart';
import '../../../data/repositories/user/user_repository.dart';
import '../../../utils/popups/loaders.dart';

class UserController extends GetxController {
  static UserController get instance => Get.find();
  RxBool loading = false.obs;
  Rx<UserModel> user = UserModel.empty().obs;

//Fetches user Details
  final userRepository = Get.put(UserRepository());

  @override
  void onInit() {
    fetchUserDetails();
    super.onInit();
  }

  Future<UserModel> fetchUserDetails() async {
    try {
      loading.value = true;
      final user = await userRepository.fetchAdminDetails();
      this.user.value = user;
      loading.value = false;
      return user;
    } catch (e) {
      loading.value = false;
      TLoaders.errorSnackBar(
          title: "something went wrong", message: e.toString());
      return UserModel.empty();
    }
  }
}
