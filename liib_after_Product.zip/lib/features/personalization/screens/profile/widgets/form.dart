import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/utils/constants/sizes.dart';
import 'package:ecommerce_admin_panel/utils/validators/validation.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

class ProfileForm  extends StatelessWidget {
  const ProfileForm ({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TRoundedContainer(
          padding: EdgeInsets.symmetric(vertical: TSizes.lg,horizontal: TSizes.md),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('kelemu',style: Theme.of(context).textTheme.headlineSmall),
              SizedBox(height: TSizes.spaceBtwSections),
              Form(child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(child: TextFormField(
                        decoration: InputDecoration(

                          hintText: 'first name',
                          label: Text('first name'),
                          prefixIcon: Icon(Iconsax.user),

                        ),

                        validator: (value)=> TValidator.validateEmptyText('fieldName', value),
                      ),),
                      SizedBox(width: TSizes.spaceBtwItems,),
                      Expanded(child: TextFormField(
                        decoration: InputDecoration(

                          hintText: 'Last name',
                          label: Text('last name'),
                          prefixIcon: Icon(Iconsax.user),

                        ),

                        validator: (value)=> TValidator.validateEmptyText('fieldName', value),
                      ),),
                    ],
                  ),
                  SizedBox(height: TSizes.spaceBtwInputFields,),
                  Row(
                    children: [
                      Expanded(child: TextFormField(decoration: InputDecoration(
                        hintText: 'email',
                        label: Text('email'),
                        prefixIcon: Icon(Iconsax.forward),
                        enabled: false,
                      ),)),
                      SizedBox(width: TSizes.spaceBtwItems),
                      Expanded(child: TextFormField(decoration: InputDecoration(
                        hintText: 'phone number',
                        label: Text('phone number'),
                        prefixIcon: Icon(Iconsax.mobile),
                      ),
                        validator: (value)=> TValidator.validateEmptyText('Phone Number', value),
                      )),
                    ],

                  ),

                ],

              ),),


              SizedBox(height: TSizes.spaceBtwSections),


             SizedBox(width: double.infinity,child: ElevatedButton(onPressed: (){}, child: Text('Update Profile')),),



            ],
          ),
        )
      ],
    );
  }
}
