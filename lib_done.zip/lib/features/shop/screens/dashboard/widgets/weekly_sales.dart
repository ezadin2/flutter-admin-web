import 'package:ecommerce_admin_panel/common/widgets/icons/t_circular_icon.dart';
import 'package:ecommerce_admin_panel/features/shop/controllers/dashboard/dashboard_controller.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../../common/widgets/containers/rounded_container.dart';
import '../../../../../utils/constants/colors.dart';
import '../../../../../utils/constants/sizes.dart';
import '../../../../../utils/device/device_utility.dart';

class TSalesGraph extends StatelessWidget {
  final bool showWeekly; // true = weekly, false = daily

  const TSalesGraph({super.key, this.showWeekly = true});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(DashBoardController());

    return TRoundedContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              TCircularIcon(
                icon: Iconsax.graph,
                backgroundColor: Colors.brown.withOpacity(0.1),
                color: Colors.brown,
                size: TSizes.md,
              ),
              const SizedBox(width: TSizes.spaceBtwItems),
              Text(
                controller.weeklySales.any((sale) => sale > 0)
                    ? 'Weekly Sales'
                    : 'Daily Sales',
                style: Theme.of(context).textTheme.headlineSmall,
              ),

            ],
          ),
          const SizedBox(height: TSizes.spaceBtwItems),

          // Reactive chart
          Obx(() {
            final salesData = showWeekly ? controller.weeklySales : controller.dailySales;

            return salesData.isNotEmpty
                ? SizedBox(
              height: 400,
              child: BarChart(
                BarChartData(
                  titlesData: buildFlTitlesData(salesData, showWeekly),
                  borderData: FlBorderData(
                    show: true,
                    border: const Border(top: BorderSide.none, right: BorderSide.none),
                  ),
                  gridData: FlGridData(
                    show: true,
                    drawHorizontalLine: true,
                    drawVerticalLine: false,
                    horizontalInterval: _calculateInterval(salesData),
                  ),
                  barGroups: salesData.asMap().entries.map((entry) {
                    return BarChartGroupData(
                      x: entry.key,
                      barRods: [
                        BarChartRodData(
                          toY: entry.value,
                          width: 30,
                          color: TColors.primary,
                          borderRadius: BorderRadius.circular(TSizes.sm),
                        )
                      ],
                    );
                  }).toList(),
                  groupsSpace: TSizes.spaceBtwItems,
                  barTouchData: BarTouchData(
                    touchTooltipData: BarTouchTooltipData(
                      getTooltipColor: (_) => TColors.secondary,
                    ),
                    touchCallback: TDeviceUtils.isDesktopScreen(context)
                        ? (barTouchEvent, barTouchResponse) {}
                        : null,
                  ),
                ),
              ),
            )
                : const SizedBox();
          }),
        ],
      ),
    );
  }

  /// Interval for y-axis based on data range
  double _calculateInterval(List<double> sales) {
    final maxSale = sales.reduce((a, b) => a > b ? a : b);
    if (maxSale <= 1000) return 100;
    if (maxSale <= 5000) return 500;
    if (maxSale <= 10000) return 1000;
    return 2000;
  }

  /// Titles for x-axis and y-axis
  FlTitlesData buildFlTitlesData(List<double> sales, bool isWeekly) {
    final now = DateTime.now();
    final dailyLabels = List.generate(7, (index) {
      final date = now.subtract(Duration(days: 6 - index));
      return '${date.month}/${date.day}';
    });

    final weeklyLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

    return FlTitlesData(
      show: true,
      bottomTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          getTitlesWidget: (value, meta) {
            final index = value.toInt();
            if (index < 0 || index >= 7) return const SizedBox();
            final label = isWeekly ? weeklyLabels[index] : dailyLabels[index];
            return SideTitleWidget(child: Text(label), space: 0, meta: meta);
          },
        ),
      ),
      leftTitles: AxisTitles(
        sideTitles: SideTitles(
          showTitles: true,
          interval: _calculateInterval(sales),
          reservedSize: 50,
        ),
      ),
      rightTitles: AxisTitles(
        sideTitles: SideTitles(showTitles: false),
      ),
      topTitles: AxisTitles(
        sideTitles: SideTitles(showTitles: false),
      ),
    );
  }
}
