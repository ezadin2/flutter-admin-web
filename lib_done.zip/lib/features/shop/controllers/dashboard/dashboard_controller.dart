import 'package:ecommerce_admin_panel/data/abstract/base_data_table_controller.dart';
import 'package:ecommerce_admin_panel/features/shop/controllers/customer/customer_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../../utils/constants/enums.dart';
import '../../../../utils/helpers/helper_functions.dart';
import '../../models/order_model.dart';
import '../order/order_controller.dart';

class DashBoardController extends TBaseController<OrderModel> {
  static DashBoardController get instance => Get.find();
  final orderController = Get.put(OrderController());
  final customerController = Get.put(CustomerController());

  final RxList<double> weeklySales = <double>[].obs;
  final RxList<double> dailySales = <double>[].obs; // ✅ New for last 7 days from today
  final RxMap<OrderStatus, int> orderStatusData = <OrderStatus, int>{}.obs;
  final RxMap<OrderStatus, double> totalAmounts = <OrderStatus, double>{}.obs;

  @override
  Future<List<OrderModel>> fetchItems() async {
    if (orderController.allItems.isEmpty) {
      await orderController.fetchItems();
    }
    if (customerController.allItems.isEmpty) {
      await customerController.fetchItems();
    }

    _calculateWeeklySales();         // ✅ Unchanged
    _calculateDailySales();          // ✅ New
    _calculateOrderStatusData();     // ✅ Unchanged

    return orderController.allItems;
  }

  // ✅ NEW: Calculate daily sales (last 7 days from today)
  void _calculateDailySales() {
    dailySales.value = List<double>.filled(7, 0.0);
    final DateTime now = DateTime.now();

    for (var order in orderController.allItems) {
      final DateTime orderDate = order.orderDate;
      final int daysAgo = now.difference(orderDate).inDays;

      if (daysAgo >= 0 && daysAgo < 7) {
        dailySales[6 - daysAgo] += order.totalAmount; // index 6 = today, 0 = 6 days ago
      }
    }

    print('Daily Sales (last 7 days): $dailySales');
  }

  // ✅ Existing: Weekly sales (Mon-Sun of current week)
  void _calculateWeeklySales() {
    weeklySales.value = List<double>.filled(7, 0.0);

    for (var order in orderController.allItems) {
      final DateTime orderWeekStart = THelperFunctions.getStartOfWeek(order.orderDate);

      if (orderWeekStart.isBefore(DateTime.now()) &&
          orderWeekStart.add(Duration(days: 7)).isAfter(DateTime.now())) {
        int index = (order.orderDate.weekday - 1) % 7;
        index = index < 0 ? index + 7 : index;
        weeklySales[index] += order.totalAmount;
      }
    }

    print('Weekly Sales: $weeklySales');
  }

  // ✅ Existing: Order status summary
  void _calculateOrderStatusData() {
    orderStatusData.clear();
    totalAmounts.value = {for (var status in OrderStatus.values) status: 0.0};
    for (var order in orderController.allItems) {
      final status = order.status;
      orderStatusData[status] = (orderStatusData[status] ?? 0) + 1;
      totalAmounts[status] = (totalAmounts[status] ?? 0) + order.totalAmount;
    }
  }

  String getDisplayStatusStringName(OrderStatus status) {
    switch (status) {
      case OrderStatus.pending:
        return 'Pending';
      case OrderStatus.processing:
        return 'Processing';
      case OrderStatus.shipped:
        return 'Shipped';
      case OrderStatus.delivered:
        return 'Delivered';
      case OrderStatus.cancelled:
        return 'Cancelled';
      default:
        return 'Unknown';
    }
  }

  // Calculate percentage change between current and previous period
  double calculatePercentageChange(double current, double previous) {
    if (previous == 0) return current == 0 ? 0 : 100; // handle divide by zero
    return ((current - previous) / previous) * 100;
  }

// In DashBoardController, ensure all calculations return double
  double getCurrentMonthSales() {
    final now = DateTime.now();
    return orderController.allItems.fold(0.0, (sum, order) {
      if (order.orderDate.month == now.month && order.orderDate.year == now.year) {
        return sum + order.totalAmount;
      }
      return sum;
    });
  }

  double getPreviousMonthSales() {
    final now = DateTime.now();
    DateTime previousMonth;
    if (now.month == 1) {
      previousMonth = DateTime(now.year - 1, 12);
    } else {
      previousMonth = DateTime(now.year, now.month - 1);
    }

    return orderController.allItems.fold(0.0, (sum, order) {
      if (order.orderDate.month == previousMonth.month &&
          order.orderDate.year == previousMonth.year) {
        return sum + order.totalAmount;
      }
      return sum;
    });
  }

// Get current month name
  String getCurrentMonthName() {
    return DateFormat('MMMM').format(DateTime.now());
  }

// Get previous month name
  String getPreviousMonthName() {
    final now = DateTime.now();
    DateTime previousMonth;
    if (now.month == 1) {
      previousMonth = DateTime(now.year - 1, 12);
    } else {
      previousMonth = DateTime(now.year, now.month - 1);
    }
    return DateFormat('MMMM yyyy').format(previousMonth);
  }

  @override
  bool containsSearchQuery(OrderModel item, String query) => false;

  @override
  Future<void> deleteItem(OrderModel item) async {}
}
