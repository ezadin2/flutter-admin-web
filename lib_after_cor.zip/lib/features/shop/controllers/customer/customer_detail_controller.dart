import 'package:ecommerce_admin_panel/common/styles/user_model.dart';
import 'package:ecommerce_admin_panel/data/repositories/user/user_repository.dart';
import 'package:ecommerce_admin_panel/features/shop/models/order_model.dart';
import 'package:ecommerce_admin_panel/utils/popups/loaders.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

import '../../../../data/repositories/AddressRepository/address_repository.dart';

class CustomerController extends GetxController {
  static CustomerController get instance => Get.find();

  RxBool orderLoading = true.obs;
  RxBool addressesLoading = true.obs;
  RxInt sortColumnIndex = 1.obs;
  RxBool sortAscending = true.obs;
  RxList<bool> selectedRows = <bool>[].obs;
  Rx<UserModel> customer = UserModel.empty().obs;
  final addressRepository = Get.put(AddressRepository());
  final searchTextController = TextEditingController();
  RxList<OrderModel> allCustomerOrder = <OrderModel>[].obs;
  RxList<OrderModel> filteredCustomerOrder = <OrderModel>[].obs;
  //
  // Future<void> getCostumerOrders() async {
  //   try {
  //     orderLoading.value = true;
  //
  //     if (customer.value.id != null && customer.value.id!.isNotEmpty) {
  //       customer.value.orders =
  //           await UserRepository.instance.fetchUserOrders(customer.value.id!);
  //     }
  //     allCustomerOrder.assignAll(customer.value.orders ?? []);
  //
  //     filteredCustomerOrder.assignAll(customer.value.orders ?? []);
  //
  //     selectedRows.assignAll(List.generate(
  //         customer.value.orders != null ? customer.value.orders!.length : 0,
  //         (index) => false));
  //   } catch (e) {
  //     TLoaders.errorSnackBar(title: 'sorry', message: e.toString());
  //   } finally {
  //     orderLoading.value = false;
  //   }
  // }
  //
  // Future<void> getCostumerAddress() async {
  //   try {
  //     orderLoading.value = true;
  //
  //     if (customer.value.id != null && customer.value.id!.isNotEmpty) {
  //       customer.value.addresses =
  //           await addressRepository.fetchUserAddresses(customer.value.id!);
  //     }
  //   } catch (e) {
  //     TLoaders.errorSnackBar(title: 'sorry', message: e.toString());
  //   } finally {
  //     addressesLoading.value = false;
  //   }
  // }
  //
  // void searchQuery(String query) {
  //   filteredCustomerOrder.assignAll(allCustomerOrder.where((customer) =>
  //       customer.id.toLowerCase().contains(query.toLowerCase() ||
  //           customer.orderDate.toString().contains(query.toLowerCase()))));
  //   update();
  // }
  // void sortById(int sortColumnIndex,bool ascending) {
  //  sortAscending.value=ascending;
  //  filteredCustomerOrder.sort(a, b){
  //    if(ascending){
  //      return a.id.toLowerCase().compareTo(b.id.toLowerCase());
  //    }else{
  //      return a.id.toLowerCase().compareTo(a.id.toLowerCase());
  //    }
  //  };
  //  this.sortColumnIndex.value=sortColumnIndex;
  //  update();
  // }
}
