import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../utils/constants/enums.dart';
import '../../../../utils/helpers/helper_functions.dart';
import '../../models/order_model.dart';

class DashBoardController extends GetxController {
  static DashBoardController get instance => Get.find();

  final RxList<double> weeklySales = <double>[].obs;
  final RxMap<OrderStatus , int> orderstatusData = <OrderStatus,int>{}.obs;
  final RxMap<OrderStatus , double> totalAmounts = <OrderStatus,double>{}.obs;

  static final List<OrderModel> orders = [
    OrderModel(
      id: 'CwT0012',
      status: OrderStatus.processing,
      totalAmount: 265,
      orderDate: DateTime.now().subtract(Duration(days: DateTime.now().weekday - 1)), // Monday of the current week
    ),
    OrderModel(
      id: 'CwT0012',
      status: OrderStatus.shipped,
      totalAmount: 500,
      orderDate: DateTime.now().subtract(Duration(days: DateTime.now().weekday - 2)), // Tuesday of the current week
    ),
    OrderModel(
      id: 'CwT0012',
      status: OrderStatus.delivered,
      totalAmount: 290,
      orderDate: DateTime.now().subtract(Duration(days: DateTime.now().weekday - 3)), // Wednesday of the current week
    ),
    OrderModel(
      id: 'CwT0012',
      status: OrderStatus.delivered,
      totalAmount: 354,
      orderDate: DateTime.now().subtract(Duration(days: DateTime.now().weekday - 4)), // Thursday of the current week
    ),
    OrderModel(
      id: 'CwT0012',
      status: OrderStatus.delivered,
      totalAmount: 355,
      orderDate: DateTime.now().subtract(Duration(days: DateTime.now().weekday - 5)), // Friday of the current week
    ),
  ];

  @override
  void onInit() {
    _calculateWeeklySales();
    _calculateOrderStatusData();
    super.onInit();
  }

  // Calculate weekly sales
  void _calculateWeeklySales() {
    // Initialize weeklySales with 7 days (Monday to Sunday)
    weeklySales.value = List<double>.filled(7, 0.0);

    // // Get the current date and the start of the current week
    // final DateTime now = DateTime.now();
    // final DateTime startOfWeek = THelperFunctions.getStartOfWeek(now);
    //
    // print('Start of Week: $startOfWeek'); // Debug print

    // Iterate through orders and calculate sales for the current week
    for (var order in orders) {
      final DateTime orderWeekStart = THelperFunctions.getStartOfWeek(order.orderDate);

      // print('Order Date: ${order.orderDate}, Order Week Start: $orderWeekStart'); // Debug print

      // Check if the order is within the current week
      if (orderWeekStart.isBefore(DateTime.now()) && orderWeekStart.add(Duration(days: 7)).isAfter(DateTime.now())) {
        int index = (order.orderDate.weekday -1)%7; // Monday = 0, Sunday = 6
        index = index < 0 ? index + 7 : index;
        weeklySales[index] += order.totalAmount;
      }
    }

    print('Weekly Sales: $weeklySales'); // Debug print to check the data
  }

  _calculateOrderStatusData(){
    orderstatusData.clear();
    totalAmounts.value = {for (var status in OrderStatus.values) status:0.0};
    for(var order in orders){
      final status = order.status;
      orderstatusData[status] = (orderstatusData[status]??0)+1;
      totalAmounts[status]= (totalAmounts[status] ?? 0) + order.totalAmount;
    }
  }

  String getDisplayStatusStringName(OrderStatus status){
    switch (status){
      case OrderStatus.pending:
        return 'Pending';
      case OrderStatus.processing:
        return 'Processing';
      case OrderStatus.shipped:
        return 'Shipped';
      case OrderStatus.delivered:
        return 'Delivered';
      case OrderStatus.cancelled:
        return 'Cancelled';
      default:
        return 'Unknown';
    }
  }
}