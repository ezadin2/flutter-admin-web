import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/utils/constants/sizes.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ShippingAddress extends StatelessWidget {
  const ShippingAddress({super.key});

  @override
  Widget build(BuildContext context) {
    return TRoundedContainer(
      padding: EdgeInsets.all(TSizes.defaultSpace),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('shpping address',style: Theme.of(context).textTheme.headlineMedium),
          SizedBox(height: TSizes.spaceBtwItems),

          Row(
            children: [
              SizedBox(width: 120,child: Text('name')),
              Text(';'),
              SizedBox(width: TSizes.spaceBtwItems/2),
Expanded(child: Text('e-commerce',style: Theme.of(context).textTheme.headlineMedium)),
            ],
          ),
          SizedBox(height: TSizes.spaceBtwItems),
          Row(
            children: [
              SizedBox(width: 120,child: Text('country')),
              Text(';'),
              SizedBox(width: TSizes.spaceBtwItems/2),
              Expanded(child: Text('wolkite',style: Theme.of(context).textTheme.headlineMedium)),
            ],
          ),
          SizedBox(height: TSizes.spaceBtwItems),
          Row(
            children: [
              SizedBox(width: 120,child: Text('phone number')),
              Text(';'),
              SizedBox(width: TSizes.spaceBtwItems/2),
              Expanded(child: Text('0924784985',style: Theme.of(context).textTheme.headlineMedium)),
            ],
          ),
          SizedBox(height: TSizes.spaceBtwItems),
          Row(
            children: [
              SizedBox(width: 120,child: Text('address')),
              Text(';'),
              SizedBox(width: TSizes.spaceBtwItems/2),
              Expanded(child: Text('street-3',style: Theme.of(context).textTheme.headlineMedium)),
            ],
          ),
        ],
      ),
    );
  }
}
