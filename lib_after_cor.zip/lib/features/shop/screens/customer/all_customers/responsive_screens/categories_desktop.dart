import 'package:ecommerce_admin_panel/common/styles/user_model.dart';
import 'package:ecommerce_admin_panel/common/widgets/breadcrumbs/bread_crumb_with_heading.dart';
import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/common/widgets/loaders/loader_animation.dart';
import 'package:ecommerce_admin_panel/features/shop/screens/customer/customer_detail/widget/customer_info.dart';
import 'package:ecommerce_admin_panel/routes/routes.dart';
import 'package:ecommerce_admin_panel/utils/constants/sizes.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../common/widgets/data_table/table_header.dart';
import '../../../../controllers/customer/customer_controller.dart';
import '../table/data_table.dart';

//import '../widgets/table_header.dart';

class CutomersDesktopScreen extends StatelessWidget {
  const CutomersDesktopScreen({super.key, required this.customer});
final UserModel customer;
  @override
  Widget build(BuildContext context) {
    final controller = Get.put(CustomerController());
    //controller.customer.value=customer;
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(TSizes.defaultSpace),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TBreadCrumbWithHeading(
                  returnToPreviousScreen:true,heading:  'Customers', breadCrumbItems: [TRoutes.customers,'Details']),
              SizedBox(
                height: TSizes.spaceBtwSections,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: Column(children: [CustomerInfo(customer: customer)],

                  ))
                ],
              ),
              TRoundedContainer(
                child: Column(
                  children: [
                    TTableHeader(
                      showLeftWidget: false,
                      searchController: controller.searchTextController,
                      searchOnChanged: (query) => controller.searchQuery(query),
                    ),
                    SizedBox(
                      height: TSizes.spaceBtwItems,
                    ),
                    Obx(() {
                      if(controller.isLoading.value) return TLoaderAnimation();
                    return  CustomerTable();
                    }),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
