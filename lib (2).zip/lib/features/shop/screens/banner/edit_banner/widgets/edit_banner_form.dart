import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/features/shop/models/category_model.dart';
import 'package:ecommerce_admin_panel/utils/constants/enums.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../../../common/widgets/images/image_uploader.dart';
import '../../../../../../common/widgets/images/t_rounded_image.dart';
import '../../../../../../utils/constants/colors.dart';
import '../../../../../../utils/constants/image_strings.dart';
import '../../../../../../utils/constants/sizes.dart';
import '../../../../../../utils/validators/validation.dart';

class EditBannerForm extends StatelessWidget {
  const EditBannerForm({super.key, required this.banner});

  final BannerModel banner;
  @override
  Widget build(BuildContext context) {
    return TRoundedContainer(
      width: 500,
      padding: const EdgeInsets.all(TSizes.defaultSpace),
      child: Form(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: TSizes.sm),
              Text(
                'Update  Banner',
                style: Theme.of(context).textTheme.headlineMedium,
              ),
              SizedBox(height: TSizes.spaceBtwSections),
              Column(
                children: [
                  GestureDetector(
                    child: TRoundedImage(
                      width: 400,
                      height: 200,
                      backgroundColor: TColors.primaryBackground,
                      image: TImages.defaultImage,
                      imageType: ImageType.asset,
                    ),
                  ),
                  SizedBox(
                    height: TSizes.spaceBtwItems,
                  ),
                  TextButton(onPressed: () {}, child: Text('Select Image')),
                ],
              ),
              SizedBox(
                height: TSizes.spaceBtwInputFields,
              ),
              Text(
                'Make Your Banner Active or InActive',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              CheckboxMenuButton(
                  value: true, onChanged: (value) {}, child: Text('Active')),
              SizedBox(
                height: TSizes.spaceBtwInputFields,
              ),
              DropdownButton<String>(
                value: 'search',
                onChanged: (String? newValue) {},
                items: [
                  DropdownMenuItem<String>(
                    value: 'Home',
                    child: Text('Home'),
                  ),
                  DropdownMenuItem<String>(
                    value: 'search',
                    child: Text('Search'),
                  ),
                ],
              ),
              SizedBox(
                height: TSizes.spaceBtwInputFields * 2,
              ),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(onPressed: () {}, child: Text('Update')),
              ),
              SizedBox(height: TSizes.spaceBtwInputFields *2,)
            ],
          )),
    );
  }
}

class BannerModel {
}
