import 'package:flutter/material.dart';

import '../../../../../common/widgets/containers/rounded_container.dart';
import '../../../../../utils/constants/sizes.dart';
import '../table/data_table.dart';
import '../widgets/order_status_pie_chart.dart';
import '../widgets/t_dashboard_card.dart';
import '../widgets/weekly_sales.dart';

class DashboardMobileScreen extends StatelessWidget {
  const DashboardMobileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      body: SingleChildScrollView(
        child: Padding(padding: EdgeInsets.all(TSizes.defaultSpace),child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Dashbord',
                style: Theme.of(context).textTheme.headlineLarge),
            const SizedBox(height: TSizes.spaceBtwSections),
            TDashboardCard(
                title: 'Sales total', subTitle: '\$365.6', stats: 25),
            SizedBox(height: TSizes.spaceBtwItems,),
            TDashboardCard(
                title: 'Average Order', subTitle: '\$25', stats: 15),
            SizedBox(height: TSizes.spaceBtwItems,),
            TDashboardCard(
                title: 'Total Order', subTitle: '\$36', stats: 44),
            SizedBox(height: TSizes.spaceBtwItems,),
            TDashboardCard(
                title: 'visitors', subTitle: '\$25.66', stats: 2),
            SizedBox(height: TSizes.spaceBtwSections,),

            ///bar graph
            const TWeeklySalesGraph(),
            const SizedBox(height: TSizes.spaceBtwSections,),

            // Orders
            TRoundedContainer(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Recent Orders',style: Theme.of(context).textTheme.headlineSmall,),
                  const SizedBox(height: TSizes.spaceBtwSections,),
                  const DashboardOrderTable()
                ],
              ),
            ),
            const SizedBox(height: TSizes.spaceBtwSections,),

            ///Pie Chart
            TOrderStatusPieChart()
          ],
        ),),
      ),
    );
  }
}
