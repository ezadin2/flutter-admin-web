import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/features/shop/models/brand_model.dart';
import 'package:ecommerce_admin_panel/utils/constants/sizes.dart';
import 'package:flutter/material.dart';
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:iconsax/iconsax.dart';


import '../../../../../../utils/constants/image_strings.dart';

class ProductBrand extends StatelessWidget {
  const ProductBrand({super.key});

  @override
  Widget build(BuildContext context) {
    return TRoundedContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Brand', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: TSizes.spaceBtwItems),
          TypeAheadField(
            builder: (context, controller, focusNode) {
              return TextFormField(
                controller: controller,
                focusNode: focusNode,
                decoration:  InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: 'Select brand',
                  suffixIcon: Icon(Iconsax.box),
                ),
              );
            },
            suggestionsCallback: (pattern)  {
              // Implement your brand suggestions logic here
              return [
                BrandModel(),
                BrandModel(),
              ];
            },
            itemBuilder: (context, suggestion) {
              return ListTile(
                title: Text("Suggesion Name"),
              );
            },
            onSelected: (suggestion) {
              // Handle brand selection
            },
          ),
        ],
      ),
    );
  }
}