import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/common/widgets/images/image_uploader.dart';
import 'package:ecommerce_admin_panel/common/widgets/images/t_rounded_image.dart';
import 'package:ecommerce_admin_panel/utils/constants/colors.dart';
import 'package:ecommerce_admin_panel/utils/constants/enums.dart';
import 'package:ecommerce_admin_panel/utils/constants/sizes.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get_state_manager/get_state_manager.dart';

import '../../../../../../utils/constants/image_strings.dart';

class ProductVariations extends StatelessWidget {
  const ProductVariations({super.key});

  @override
  Widget build(BuildContext context) {
    return TRoundedContainer(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('product variation',
                  style: Theme.of(context).textTheme.headlineSmall),
              TextButton(onPressed: () {}, child: Text('Remove variation')),
            ],
          ),
          SizedBox(height: TSizes.spaceBtwItems),
          ListView.separated(
              itemCount: 2,
              shrinkWrap: true,
              separatorBuilder: (_, __) =>
                  SizedBox(height: TSizes.spaceBtwItems),
              itemBuilder: (_, index) {
                return _buildvariationTile();
              }),
          _buildNoVariationsMessage(),
        ],
      ),
    );
  }

  Widget _buildvariationTile() {
    return ExpansionTile(
      backgroundColor: TColors.lightGrey,
      collapsedBackgroundColor: TColors.lightGrey,
      childrenPadding: EdgeInsets.all(TSizes.md),
      expandedCrossAxisAlignment: CrossAxisAlignment.start,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(TSizes.borderRadiusLg)),
      title: Text('color : Green,Sizes:Small'),
      children: [
        TImageUploader(
          right: 0,
          left: null,
          imageType: ImageType.asset,
          image: TImages.defaultImage,
          onIconButtonPressed: () {},
        ),
        SizedBox(height: TSizes.spaceBtwInputFields),
        Row(
          children: [
            Expanded(
              child: TextFormField(
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.digitsOnly
                ],
                decoration: InputDecoration(
                    labelText: 'stock',
                    hintText: 'add stock,only number are allowed'),
              ),
            ),
            SizedBox(width: TSizes.spaceBtwInputFields),
            Expanded(
                child: TextFormField(
              keyboardType: TextInputType.numberWithOptions(decimal: true),
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}$')),
              ],
              decoration: InputDecoration(
                  labelText: 'discounted price',
                  hintText: 'price with up to 2 deccimal'),
            ))
          ],
        ),
        SizedBox(height: TSizes.spaceBtwInputFields),
        TextFormField(
          decoration: InputDecoration(
              labelText: 'description ',
              hintText: 'add description of thise variation ...'),
        ),
        SizedBox(height: TSizes.spaceBtwInputFields),
      ],
    );
  }

  Widget _buildNoVariationsMessage() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TRoundedImage(
                width: 200,
                height: 200,
                imageType: ImageType.asset,
                image: TImages.defaultAttributeColorsImageIcon),
          ],
        ),
        SizedBox(height: TSizes.spaceBtwInputFields),
        Text('there are no variation addes for thise product'),
      ],
    );
  }
}
