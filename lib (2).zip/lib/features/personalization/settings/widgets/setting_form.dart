import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/utils/constants/sizes.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

class SettingForm extends StatelessWidget {
  const SettingForm({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TRoundedContainer(
          padding: EdgeInsets.symmetric(
            vertical: TSizes.lg,
            horizontal: TSizes.md,
          ),
          child: Form(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'App Setting',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                SizedBox(height: TSizes.spaceBtwSections),

                /// App Name
                TextFormField(
                  decoration: InputDecoration(
                    hintText: 'App name',
                    label: Text('App name'),
                    prefixIcon: Icon(Iconsax.user),
                  ),
                ),
                SizedBox(height: TSizes.spaceBtwInputFields),

                /// Tax & Shipping Inputs
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        decoration: InputDecoration(
                          hintText: 'Tax %',
                          label: Text('Tax Rate (%)'),
                          prefixIcon: Icon(Iconsax.tag),
                        ),
                      ),
                    ),
                    SizedBox(width: TSizes.spaceBtwItems),
                    Expanded(
                      child: TextFormField(
                        decoration: InputDecoration(
                          hintText: 'Shipping',
                          label: Text('Shippinh cost (ETB)'),
                          prefixIcon: Icon(Iconsax.ship),
                        ),
                      ),
                    ),
                    SizedBox(width: TSizes.spaceBtwItems),
                    Expanded(
                      child: TextFormField(
                        decoration: InputDecoration(
                          hintText: 'Free shipping',
                          label: Text('Free shipping Threshhold'),
                          prefixIcon: Icon(Iconsax.ship),
                        ),
                      ),
                    ),
                  ],
                ),

                SizedBox(height: TSizes.spaceBtwSections),

                /// Submit Button (moved out of the Row)
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {},
                    child: Text('Update App Setting'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
