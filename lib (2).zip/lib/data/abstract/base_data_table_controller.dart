import 'package:ecommerce_admin_panel/utils/popups/full_screen_loader.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../features/shop/models/category_model.dart';
import '../../utils/constants/sizes.dart';
import '../../utils/popups/loaders.dart';

abstract class TBaseController<T> extends GetxController {
  RxBool isLoading = false.obs;
  RxInt sortColumnIndex = 1.obs;
  RxBool sortAscending = true.obs;
  RxList<T> allItems = <T>[].obs;
  RxList<T> filteredItems = <T>[].obs;
  RxList<bool> selectedRows = <bool>[].obs;
  final searchTextController = TextEditingController();

  @override
  void onInit() {
    fetchData();
    super.onInit();
  }

  // Remove one of the duplicate deleteItem declarations
  Future<void> deleteItem(T item);

  bool containsSearchQuery(T item, String query);

  Future<List<T>> fetchItems();

  Future<void> fetchData() async {
    try {
      isLoading.value = true;
      final fetchedItems = await fetchItems(); // Always fetch fresh data
      allItems.assignAll(fetchedItems);
      filteredItems.assignAll(allItems);
      selectedRows.assignAll(List.generate(allItems.length, (_) => false));
      isLoading.value = false; // Don't forget this!
    } catch (e) {
      isLoading.value = false;
      TLoaders.errorSnackBar(title: 'Oh sorry', message: e.toString());
      // Consider assigning empty lists or keeping old data
      allItems.assignAll([]);
      filteredItems.assignAll([]);
    }
  }
  void searchQuery(String query) {
    filteredItems.assignAll(
      allItems.where((item) => containsSearchQuery(item, query)),
    );
  }
  void sortByProperty(int sortColumnIndex, bool ascending, Function(T) property) {
    sortAscending.value = ascending;
    this.sortColumnIndex.value = sortColumnIndex;
    filteredItems.sort((a, b) {
      if (ascending) {
        return property(a).compareTo(property(b));
      } else {
        return property(b).compareTo(property(a));
      }
    });
  }




  void addItemToLists(T item) {
    allItems.add(item);
    filteredItems.add(item);
    selectedRows.assignAll(List.generate(allItems.length, (index) => false));
  }

  void updateItemsFromLists(T item) {
    final itemIndex = allItems.indexWhere((i) => i == item);
    final filteredIndex = filteredItems.indexWhere((i) => i == item);

    if(itemIndex != -1) allItems[itemIndex] = item;
    if(filteredIndex != -1) filteredItems[filteredIndex] = item;
    filteredItems.refresh();
  }

  void removeItemFromList(T item) {  // Changed parameter type from CategoryModel to T
    allItems.remove(item);
    filteredItems.remove(item);
    selectedRows.assignAll(List.generate(allItems.length, (index) => false));
  }


  confirmAndDeleteItem(T category) {
    Get.defaultDialog(
      title: 'delete item',
      content: Text('are you sure you want to delete delete this item'),
      confirm: SizedBox(
        width: 60,
        child: ElevatedButton(onPressed: ()async =>await deleteOnConfirm(category),
          style: OutlinedButton.styleFrom(
            padding: EdgeInsets.symmetric(vertical: TSizes.buttonHeight /2),
            shape : RoundedRectangleBorder(borderRadius: BorderRadius.circular(TSizes.buttonRadius * 5)),
          ),
          child: const Text('ok'),
        ),

      ),
      cancel: SizedBox(
        width: 60,
        child: OutlinedButton(onPressed: ()=>Get.back(),
          style: OutlinedButton.styleFrom(
            padding: EdgeInsets.symmetric(vertical: TSizes.buttonHeight /2),
            shape : RoundedRectangleBorder(borderRadius: BorderRadius.circular(TSizes.buttonRadius * 5)),
          ),
          child: const Text('ok'),
        ),

      ),
    );
  }

  Future<void> deleteOnConfirm(T item) async {  // Changed parameter type and moved inside class
    try {
      TFullScreenLoader.popUpCircular();
      await deleteItem(item);
      removeItemFromList(item);
      TFullScreenLoader.stopLoading();
      TLoaders.successSnackBar(title: 'Item Deleted', message: 'Your Item has been Deleted');
    } catch(e) {
      TFullScreenLoader.stopLoading();
      TLoaders.errorSnackBar(title: 'Oh snap', message: e.toString());
    }
  }
}