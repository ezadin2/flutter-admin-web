import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/common/widgets/images/image_uploader.dart';
import 'package:ecommerce_admin_panel/utils/constants/enums.dart';
import 'package:ecommerce_admin_panel/utils/constants/image_strings.dart';
import 'package:ecommerce_admin_panel/utils/constants/sizes.dart';
import 'package:ecommerce_admin_panel/utils/validators/validation.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

class CreateCategoryForm extends StatelessWidget {
  const CreateCategoryForm({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return TRoundedContainer(
      width: 500,
      padding: const EdgeInsets.all(TSizes.defaultSpace),
      child: Form(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: TSizes.sm),
              TextFormField(
                validator: (value) => TValidator.validateEmptyText('name', value),
                decoration: const InputDecoration(
                    labelText: 'category', prefixIcon: Icon(Iconsax.category)),
              ),
              const SizedBox(height: TSizes.spaceBtwInputFields),
              DropdownButtonFormField(
                decoration: const InputDecoration(
                    hintText: 'parent category',
                    labelText: 'parent category',
                    prefixIcon: Icon(Iconsax.bezier)),
                onChanged: (newValue) {},
                items: [
                  DropdownMenuItem(
                    value: '',
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [Text("item.name")],
                    ),
                  )
                ],
              ),
              const SizedBox(height: TSizes.spaceBtwInputFields * 2),

              TImageUploader(
                  width: 80,
                  height: 80,
                  image: TImages.defaultImage,
                  imageType: ImageType.asset,
                  onIconButtonPressed: () {}),
              const SizedBox(height: TSizes.spaceBtwInputFields),
              CheckboxMenuButton(value: true, onChanged: (value){}, child: const Text('feature'),),
              const SizedBox(height: TSizes.spaceBtwInputFields * 2),
            ],
          )),
    );
  }
}
