import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/features/shop/models/category_model.dart';
import 'package:ecommerce_admin_panel/utils/constants/enums.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../../../common/widgets/images/image_uploader.dart';
import '../../../../../../utils/constants/image_strings.dart';
import '../../../../../../utils/constants/sizes.dart';
import '../../../../../../utils/validators/validation.dart';

class EditCategoryForm extends StatelessWidget {
  const EditCategoryForm({super.key, required this.category});

  final CategoryModel category;
  @override
  Widget build(BuildContext context) {
    return TRoundedContainer(
      width: 500,
      padding: const EdgeInsets.all(TSizes.defaultSpace),
      child: Form(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('update new Category',style: Theme.of(context).textTheme.headlineMedium,),
              SizedBox(height: TSizes.spaceBtwSections,),

              TextFormField(
                validator: (value) => TValidator.validateEmptyText('name', value),
                decoration: const InputDecoration(
                    labelText: 'category name', prefixIcon: Icon(Iconsax.category)),
              ),
              const SizedBox(height: TSizes.spaceBtwInputFields),
              DropdownButtonFormField(
                decoration: const InputDecoration(
                    hintText: 'parent category',
                    labelText: 'parent category',
                    prefixIcon: Icon(Iconsax.bezier)),
                onChanged: (newValue) {},
                items: [
                  DropdownMenuItem(
                    value: '',
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [Text("item.name")],
                    ),
                  )
                ],
              ),
              const SizedBox(height: TSizes.spaceBtwInputFields * 2),

              TImageUploader(
                  width: 80,
                  height: 80,
                  image: TImages.defaultImage,
                  imageType: ImageType.asset,
                  onIconButtonPressed: () {}),
              const SizedBox(height: TSizes.spaceBtwInputFields),
              CheckboxMenuButton(value: true, onChanged: (value){}, child: const Text('feature'),),
              const SizedBox(height: TSizes.spaceBtwInputFields * 2),
            ],
          )),
    );
  }
}
