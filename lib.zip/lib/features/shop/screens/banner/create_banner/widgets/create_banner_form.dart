import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/common/widgets/images/image_uploader.dart';
import 'package:ecommerce_admin_panel/common/widgets/images/t_rounded_image.dart';
import 'package:ecommerce_admin_panel/utils/constants/colors.dart';
import 'package:ecommerce_admin_panel/utils/constants/enums.dart';
import 'package:ecommerce_admin_panel/utils/constants/image_strings.dart';
import 'package:ecommerce_admin_panel/utils/constants/sizes.dart';
import 'package:ecommerce_admin_panel/utils/validators/validation.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

class CreateBannerForm extends StatelessWidget {
  const CreateBannerForm({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return TRoundedContainer(
      width: 500,
      padding: const EdgeInsets.all(TSizes.defaultSpace),
      child: Form(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: TSizes.sm),
          Text(
            'Create New Banner',
            style: Theme.of(context).textTheme.headlineMedium,
          ),
          SizedBox(height: TSizes.spaceBtwSections),
          Column(
            children: [
              GestureDetector(
                child: TRoundedImage(
                  width: 400,
                  height: 200,
                  backgroundColor: TColors.primaryBackground,
                  image: TImages.defaultImage,
                  imageType: ImageType.asset,
                ),
              ),
              SizedBox(
                height: TSizes.spaceBtwItems,
              ),
              TextButton(onPressed: () {}, child: Text('Select Image')),
            ],
          ),
          SizedBox(
            height: TSizes.spaceBtwInputFields,
          ),
          Text(
            'Make Your Banner Active or InActive',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          CheckboxMenuButton(
              value: true, onChanged: (value) {}, child: Text('Active')),
          SizedBox(
            height: TSizes.spaceBtwInputFields,
          ),
          DropdownButton<String>(
            value: 'search',
            onChanged: (String? newValue) {},
            items: [
              DropdownMenuItem<String>(
                value: 'Home',
                child: Text('Home'),
              ),
              DropdownMenuItem<String>(
                value: 'search',
                child: Text('Search'),
              ),
            ],
          ),
          SizedBox(
            height: TSizes.spaceBtwInputFields * 2,
          ),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(onPressed: () {}, child: Text('Create')),
          ),
          SizedBox(height: TSizes.spaceBtwInputFields *2,)
        ],
      )),
    );
  }
}
