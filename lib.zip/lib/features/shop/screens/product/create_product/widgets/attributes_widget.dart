import 'package:ecommerce_admin_panel/common/widgets/containers/rounded_container.dart';
import 'package:ecommerce_admin_panel/common/widgets/images/t_rounded_image.dart';
import 'package:ecommerce_admin_panel/utils/constants/colors.dart';
import 'package:ecommerce_admin_panel/utils/constants/enums.dart';
import 'package:ecommerce_admin_panel/utils/constants/sizes.dart';
import 'package:ecommerce_admin_panel/utils/device/device_utility.dart';
import 'package:ecommerce_admin_panel/utils/validators/validation.dart';
import 'package:flutter/material.dart';
import 'package:iconsax/iconsax.dart';

import '../../../../../../utils/constants/image_strings.dart';

class ProductAttributes extends StatelessWidget {
  const ProductAttributes({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(color: TColors.primaryBackground),
        SizedBox(height: TSizes.spaceBtwItems),
        Text('add product attribute',
            style: Theme.of(context).textTheme.headlineSmall),
        SizedBox(height: TSizes.spaceBtwItems),
        Form(
            child: TDeviceUtils.isDesktopScreen(context)
                ? Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: _buildAttributeName()),
                      SizedBox(width: TSizes.spaceBtwItems),
                      Expanded(flex: 2, child: _buildAttributTextField()),
                      SizedBox(
                        width: TSizes.spaceBtwItems,
                      ),
                      _buildAddAttributeButton(),
                    ],
                  )
                : Column(
                    children: [
                      _buildAttributeName(),
                      SizedBox(height: TSizes.spaceBtwItems),
                      _buildAttributTextField(),
                      SizedBox(height: TSizes.spaceBtwItems),
                      _buildAddAttributeButton()
                    ],
                  )),
        SizedBox(height: TSizes.spaceBtwItems),
        Text('all attribute', style: Theme.of(context).textTheme.headlineSmall),
        SizedBox(height: TSizes.spaceBtwItems),
        TRoundedContainer(
          backgroundColor: TColors.primaryBackground,
          child: Column(
            children: [
              buildAttributesList(context),
              buildEmptyAttributes(),
            ],
          ),
        ),
        SizedBox(height: TSizes.spaceBtwSections),
        Center(
          child: SizedBox(
            width: 200,
            child: ElevatedButton.icon(
              icon: Icon(Iconsax.activity),
              label: Text('generate variation'),
              onPressed: () {},
            ),
          ),
        )
      ],
    );
  }

  ListView buildAttributesList(BuildContext context) {
    return ListView.separated(
      itemCount: 3,
      shrinkWrap: true,
      separatorBuilder: (_, __) => SizedBox(height: TSizes.spaceBtwItems),
      itemBuilder: (_, index) {
        return Container(
          decoration: BoxDecoration(
            color: TColors.white,
            borderRadius: BorderRadius.circular(TSizes.borderRadiusLg),
          ),
          child: ListTile(
            title: Text('color'),
            subtitle: Text('green,orange,pink'),
            trailing: IconButton(
                onPressed: () {},
                icon: Icon(
                  Iconsax.trash,
                  color: TColors.error,
                )),
          ),
        );
      },
    );
  }

  Column buildEmptyAttributes() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TRoundedImage(
              width: 150,
              height: 80,
              imageType: ImageType.asset,
              image: TImages.defaultAttributeColorsImageIcon,
            )
          ],
        ),
        SizedBox(height: TSizes.spaceBtwItems),
        Text('there are no attribute added or for these product'),
      ],
    );
  }
}

SizedBox _buildAddAttributeButton() {
  return SizedBox(
    width: 100,
    child: ElevatedButton.icon(
      onPressed: () {},
      icon: Icon(Iconsax.add),
      style: ElevatedButton.styleFrom(
        foregroundColor: TColors.black,
        backgroundColor: TColors.secondary,
        side: BorderSide(color: TColors.secondary),
      ),
      label: Text('add'),
    ),
  );
}

// class _buildAttributeButton() {
//
// }

TextFormField _buildAttributeName() {
  return TextFormField(
    validator: (value) => TValidator.validateEmptyText('attribute name', value),
    decoration: InputDecoration(
        labelText: 'attribute name', hintText: 'colors ,sizes ,material'),
  );
}

SizedBox _buildAttributTextField() {
  return SizedBox(
    height: 80,
    child: TextFormField(
      expands: true,
      maxLines: null,
      textAlign: TextAlign.start,
      keyboardType: TextInputType.multiline,
      textAlignVertical: TextAlignVertical.top,
      validator: (value) =>
          TValidator.validateEmptyText('attribute field', value),
      decoration: InputDecoration(
        labelText: 'attribute',
        hintText: 'add attribute separated by | example: blue | yellow',
        alignLabelWithHint: true,
      ),
    ),
  );
}
