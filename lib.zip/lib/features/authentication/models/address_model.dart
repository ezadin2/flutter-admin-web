import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../utils/formatters/formatter.dart';


class AddressModel {
  String id;
  final String name;
  final String phoneNumber;
  final String street;
  final String city;
  final String state;
  final String postcode;
  final String country;
  final double latitude;
  final double longitude;
  final DateTime? dateTime;
  bool selectedAddress;

  AddressModel({
    required this.id,
    required this.name,
    required this.phoneNumber,
    required this.street,
    required this.city,
    required this.state,
    required this.postcode,
    required this.country,
    required this.latitude,
    required this.longitude,
    this.dateTime,
    this.selectedAddress = true,
  });

  String get formattedphoneNo => TFormatter.formatPhoneNumber(phoneNumber);

  static AddressModel empty() => AddressModel(
    id: '',
    name: '',
    phoneNumber: '',
    street: '',
    city: '',
    state: '',
    postcode: '',
    country: '',
    latitude: 0.0,
    longitude: 0.0,
  );

  Map<String, dynamic> toJson() {
    return {
      'Id': id,
      'Name': name,
      'PhoneNumber': phoneNumber,
      'Street': street,
      'City': city,
      'State': state,
      'PostalCode': postcode,
      'Country': country,
      'Latitude': latitude,
      'Longitude': longitude,
      'DateTime': DateTime.now(),
      'SelectedAddress': selectedAddress,
    };
  }

  factory AddressModel.fromMap(Map<String, dynamic> data) {
    return AddressModel(
      id: data['Id'] as String,
      name: data['Name'] as String,
      phoneNumber: data['PhoneNumber'] as String,
      street: data['Street'] as String,
      city: data['City'] as String,
      state: data['State'] as String,
      postcode: data['PostalCode'] as String,
      country: data['Country'] as String,
      latitude: (data['Latitude'] as num).toDouble(),
      longitude: (data['Longitude'] as num).toDouble(),
      selectedAddress: data['SelectedAddress'] as bool,
      dateTime: (data['DateTime'] as Timestamp).toDate(),
    );
  }

  factory AddressModel.fromDocumentSnapshot(DocumentSnapshot snapshot) {
    final data = snapshot.data() as Map<String, dynamic>;
    return AddressModel(
      id: snapshot.id,
      name: data['Name'] ?? '',
      phoneNumber: data['PhoneNumber'] ?? '',
      street: data['Street'] ?? '',
      city: data['City'] ?? '',
      state: data['State'] ?? '',
      postcode: data['PostalCode'] ?? '',
      country: data['Country'] ?? '',
      latitude: (data['Latitude'] ?? 0.0).toDouble(),
      longitude: (data['Longitude'] ?? 0.0).toDouble(),
      selectedAddress: data['SelectedAddress'] as bool,
      dateTime: data['DateTime'] != null ? (data['DateTime'] as Timestamp).toDate() : null,
    );
  }

  @override
  String toString() {
    return '$street, $city, $state, $postcode, $country';
  }
}
