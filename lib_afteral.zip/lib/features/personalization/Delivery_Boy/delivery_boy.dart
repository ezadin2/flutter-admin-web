import 'package:ecommerce_admin_panel/common/widgets/breadcrumbs/bread_crumb_with_heading.dart';
import 'package:ecommerce_admin_panel/utils/constants/sizes.dart';
import 'package:flutter/material.dart';

import 'deliivery_list_screen.dart';
import 'delivary_form.dart';

class DeliveryBoyScreen extends StatelessWidget {
  const DeliveryBoyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(TSizes.defaultSpace),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TBreadCrumbWithHeading(heading: 'Delivery', breadCrumbItems: ['Delivary']),
              SizedBox(width: TSizes.spaceBtwSections),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: DeliveryListScreen()),
                  SizedBox(width: TSizes.spaceBtwSections),

                  Expanded(flex: 2,child: DelivaryForm()),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
